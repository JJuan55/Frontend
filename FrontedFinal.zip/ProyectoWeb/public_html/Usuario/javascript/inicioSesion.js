document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('loginForm');

    form.addEventListener('submit', function (e) {
        if (!form.checkValidity()) {
            e.preventDefault();
            alert('Por favor completa todos los campos requeridos con un formato válido.');
        }
    });

    // Inicializa Google Auth2
    gapi.load('auth2', function () {
        gapi.auth2.init({
            client_id: 'TU_CLIENT_ID.apps.googleusercontent.com', // Reemplaza esto con tu ID
            scope: 'profile email'
        });
    });
});

function signIn() {
    const auth2 = gapi.auth2.getAuthInstance();
    auth2.signIn().then(function (googleUser) {
        const profile = googleUser.getBasicProfile();
        const name = profile.getName();
        const email = profile.getEmail();
        const id = profile.getId();

        document.getElementById('google-login-result').innerHTML =
            `<p>Bienvenido, ${name} (${email})</p>`;

        // Aquí podrías enviar el token o correo al servidor con fetch o AJAX
    }).catch(function (error) {
        console.error('Error al iniciar sesión con Google:', error);
    });
}
//Nueva parte
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('loginForm');

    form.addEventListener('submit', function (e) {
        e.preventDefault(); // Siempre previene el envío por defecto

        if (!form.checkValidity()) {
            alert('Por favor completa todos los campos requeridos con un formato válido.');
            return;
        }

        // Captura los datos
        const correo = document.getElementById('correo').value;
        const contrasena = document.getElementById('contrasena').value;

        // Enviar al backend
        fetch("http://localhost:8081/api/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ correo, contrasena })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Error en la respuesta del servidor.");
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            alert(data.mensaje || "Inicio de sesión exitoso");
            // Aquí puedes redirigir si todo salió bien:
            // window.location.href = "pagina_principal.html";
        })
        .catch(error => {
            console.error("Error en la solicitud:", error);
            alert("Correo o contraseña incorrectos, o el servidor no respondió.");
        });
    });
});