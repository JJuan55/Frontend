function manejarSesion() {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    const loginBtn = document.getElementById("loginBtn");
    const profileIcon = document.getElementById("profileIcon");
    const ventasLink = document.getElementById("ventasLink");
    const adminLink = document.getElementById("adminLink");

    if (loginBtn && profileIcon) {
        if (usuario) {
            loginBtn.style.display = "none";
            profileIcon.style.display = "inline-block";

            // Mostrar enlaces según el rol
            if (ventasLink) ventasLink.style.display = "none";
            if (adminLink) adminLink.style.display = "none";

            if (usuario.rol === "vendedor" && ventasLink) {
                ventasLink.style.display = "block";
            }

            if ((usuario.rol === "admin" || usuario.rol === "moderador") && adminLink) {
                adminLink.style.display = "block";
            }
        } else {
            loginBtn.style.display = "inline-block";
            profileIcon.style.display = "none";
        }
    }
}

function manejarMenuPerfil() {
    const profileIcon = document.getElementById("profileIcon");
    const profileMenu = document.getElementById("profileMenu");

    if (!profileIcon || !profileMenu) return;

    profileIcon.addEventListener("click", (e) => {
        e.preventDefault();
        profileMenu.style.display = profileMenu.style.display === "block" ? "none" : "block";
    });

    document.addEventListener("click", function (e) {
        if (!profileIcon.contains(e.target) && !profileMenu.contains(e.target)) {
            profileMenu.style.display = "none";
        }
    });

    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("usuario");
            window.location.href = "index.html";
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    manejarSesion();
    manejarMenuPerfil();
});
