document.addEventListener('DOMContentLoaded', () => {
  const btnSubir = document.getElementById('btnSubirProducto');
  const modal = document.getElementById('modalProducto');
  const cerrarModal = document.getElementById('cerrarModal');
  const form = document.getElementById('formProducto');
  const contenedorVenta = document.getElementById('enVenta');
  const contenedorVendidos = document.getElementById('vendidos');

  const productosVendidos = [
    {
      nombre: "Bolso reciclado",
      tipo: "bolsos",
      precio: 18000,
      disponible: true,
      descripcion: "Bolso hecho a mano con materiales reciclados.",
      comprador: "María López",
      imagen: "https://i.pinimg.com/222x/82/c4/3f/82c43f3ad354a70f2241eb83a8d7b750.jpg"
    },
    {
      nombre: "Maceta ecológica",
      tipo: "macetas",
      precio: 12000,
      disponible: true,
      descripcion: "Maceta ecológica ideal para tu jardín.",
      comprador: "Carlos Ruiz",
      imagen: "https://i.pinimg.com/236x/24/3e/bd/243ebdb3a754407943a2d1db8b4575ab.jpg"
    }
  ];

  const productosEnVenta = [
    {
      nombre: "Maceta ecológica",
      tipo: "macetas",
      precio: 12000,
      disponible: true,
      descripcion: "Maceta ecológica ideal para tu jardín.",
      comprador: "Carlos Ruiz",
      imagen: "https://i.pinimg.com/236x/24/3e/bd/243ebdb3a754407943a2d1db8b4575ab.jpg"
    },
  ];

  const renderProductos = (lista, contenedor, esVendido = false) => {
    contenedor.innerHTML = '';
    lista.forEach((p, index) => {
      const productoDiv = document.createElement('div');
      productoDiv.classList.add('producto');

      const imagen = document.createElement('img');
      imagen.src = p.imagen;
      imagen.alt = p.nombre;

      const nombre = document.createElement('h3');
      nombre.textContent = p.nombre;

      const precio = document.createElement('p');
      precio.textContent = `$${p.precio.toFixed(2)}`;

      productoDiv.appendChild(imagen);
      productoDiv.appendChild(nombre);
      productoDiv.appendChild(precio);

      // Botones solo si NO ha sido vendido
      if (!esVendido) {
        const contenedorBotones = document.createElement('div');
        contenedorBotones.classList.add('botones-venta');

        const btnEditar = document.createElement('button');
        btnEditar.classList.add('boton-editar');
        btnEditar.textContent = 'Editar venta';
        btnEditar.addEventListener('click', (e) => {
          e.stopPropagation();
          alert(`Editar producto: ${p.nombre}`);
          // Aquí puedes mostrar el modal de edición
        });

        const btnEliminar = document.createElement('button');
        btnEliminar.classList.add('boton-eliminar');
        btnEliminar.textContent = 'Eliminar venta';
        btnEliminar.addEventListener('click', (e) => {
          e.stopPropagation();
          if (confirm(`¿Estás seguro de eliminar "${p.nombre}"?`)) {
            productosEnVenta.splice(index, 1);
            renderProductos(productosEnVenta, contenedorVenta);
          }
        });

        contenedorBotones.appendChild(btnEditar);
        contenedorBotones.appendChild(btnEliminar);
        productoDiv.appendChild(contenedorBotones);
      }

      productoDiv.addEventListener('click', () => {
        mostrarInfoProducto(
          p.nombre,
          p.descripcion || 'Sin descripción',
          esVendido ? p.comprador : null,
          esVendido ? '2024-12-01' : null,
          p.imagen
        );
      });

      contenedor.appendChild(productoDiv);
    });
  };

  renderProductos(productosEnVenta, contenedorVenta, false);
  renderProductos(productosVendidos, contenedorVendidos, true);

  btnSubir.addEventListener('click', () => {
    modal.style.display = 'block';
  });

  cerrarModal.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  window.addEventListener('click', (e) => {
    if (e.target === modal) modal.style.display = 'none';
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const inputs = form.querySelectorAll('input');
    const nuevo = {
      nombre: inputs[0].value,
      precio: parseInt(inputs[1].value),
      tipo: inputs[2].value,
      imagen: inputs[3].value
    };
    productosEnVenta.push(nuevo);
    renderProductos(productosEnVenta, contenedorVenta);
    form.reset();
    modal.style.display = 'none';
  });
});

function mostrarInfoProducto(nombre, descripcion, comprador = null, fecha = null, imagen) {
  document.getElementById('modalTitulo').textContent = nombre;
  document.getElementById('modalDescripcion').textContent = descripcion;
  document.getElementById('modalImagen').src = imagen;

  const extra = comprador && fecha
    ? `Vendido a: ${comprador} el día ${fecha}`
    : 'Este producto aún no ha sido vendido.';
  document.getElementById('modalExtra').textContent = extra;

  document.getElementById('modalInfo').style.display = "block";
}

document.querySelector('#modalInfo .close').onclick = function () {
  document.getElementById('modalInfo').style.display = "none";
};

window.onclick = function (event) {
  const modal = document.getElementById('modalInfo');
  if (event.target === modal) {
    modal.style.display = "none";
  }
};
